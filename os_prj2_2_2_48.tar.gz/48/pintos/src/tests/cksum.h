#ifndef TESTS_CKSUM_H
#define TESTS_CKSUM_H

#include <stddef.h>

unsigned long cksum(const void *, size_t);

#endif /* tests/cksum.h */
